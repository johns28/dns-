package io.github.ulysseszh.sunproxy

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/**
 * No-UI activity used ONLY to obtain VPN permission once.
 * If permission is already granted, it just starts the VPN service and finishes.
 *
 * You can start it via adb:
 *   adb shell am start -n io.github.ulysseszh.sunproxy/.MainActivity
 */
class MainActivity : ComponentActivity() {

    private val vpnLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            // Permission result is stored by the system; just try to start again.
            startVpnIfAllowed()
            finish()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startVpnIfAllowed()
        finish()
    }

    private fun startVpnIfAllowed() {
        val prepare = VpnService.prepare(this)
        if (prepare != null) {
            vpnLauncher.launch(prepare)
            return
        }
        // Permission already granted
        startService(Intent(this, MyVpnService::class.java).apply {
            action = MyVpnService.ACTION_START
        })
    }
}
