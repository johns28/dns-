package io.github.ulysseszh.sunproxy

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.util.Log

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) return

        // Start only if VPN permission was granted at least once.
        if (VpnService.prepare(context) != null) {
            Log.w("SunProxy", "VPN permission not granted yet; cannot start on boot.")
            return
        }

        val svc = Intent(context, MyVpnService::class.java).apply {
            action = MyVpnService.ACTION_START
        }
        context.startForegroundService(svc)
    }
}
